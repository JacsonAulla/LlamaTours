package com.spring.llamatours.enums;

public enum MetodoPago {
    TARJETA,
    PAYPAL,
    EFECTIVO
}

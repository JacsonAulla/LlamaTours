package com.spring.llamatours.enums;

public enum RolNombre {
    ADMIN,
    USUARIO
}

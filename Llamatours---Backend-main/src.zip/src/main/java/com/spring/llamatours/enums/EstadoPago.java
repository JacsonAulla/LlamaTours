package com.spring.llamatours.enums;

public enum EstadoPago {
    PENDIENTE,
    COMPLETADO,
    RECHAZADO,
    REEMBOLSADO
}

package com.spring.llamatours;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LlamatoursApplicationTests {

	@Test
	void contextLoads() {
	}

}
